"""
Généralisation : effet des fermetures d'origine conflictuelle sur le trafic (15 cas).

Pour chaque fermeture :
- unité traitée = le(s) port(s) ou le détroit touchés (escales mensuelles, ou escales de pétroliers
  pour les terminaux pétroliers) ;
- CONTRÔLE SYNTHÉTIQUE : combinaison pondérée (poids >= 0, somme = 1) de ports/détroits non touchés
  qui reproduit au mieux l'unité traitée pendant les 24 mois avant la fermeture ;
- effet = écart moyen (en %) entre l'unité traitée et son synthétique après la fermeture ;
- TEST PLACEBO : on refait le calcul en traitant fictivement chaque port témoin ;
  p-valeur = rang de l'effet réel (ratio RMSPE après/avant) parmi les placebos.
Puis effet MOYEN des 15 fermetures, avec intervalle de confiance et test de permutation groupé.

Règle de date : un mois de début = mois de la fermeture si elle a lieu avant le 16, sinon mois suivant.
"""
import numpy as np
import pandas as pd
from scipy.optimize import minimize

D = "/home/claude/data/"
RNG = np.random.default_rng(42)

# ------------------------------------------------------------------ séries mensuelles
gg = pd.read_csv(D + "activite.csv", parse_dates=["date"])
mo = pd.read_csv(D + "act_monde.csv", parse_dates=["date"])
act = pd.concat([gg, mo[gg.columns]], ignore_index=True)
act = act[act.date < "2026-10-01"]
pays = act.drop_duplicates("portid").set_index("portid").ISO3
nom = act.drop_duplicates("portid").set_index("portid").portname
M = {c: act.pivot_table(index=pd.Grouper(key="date", freq="MS"), columns="portid", values=c, aggfunc="sum")
     for c in ["portcalls", "portcalls_tanker"]}
det = pd.read_csv(D + "detroits.csv", parse_dates=["date"])
det = det[det.date < "2026-10-01"]
MD = det.pivot_table(index=pd.Grouper(key="date", freq="MS"), columns="portname", values="n_total", aggfunc="sum")

pid = {v: k for k, v in nom.items()}
P = lambda *names: [pid[n] for n in names]

GOLFE = ["ARE", "SAU", "QAT", "KWT", "IRQ", "BHR", "IRN", "OMN"]
MER_ROUGE = ["EGY", "SDN", "DJI", "YEM", "ISR", "SAU"]

# id, libellé, type de série, unités traitées, début, fin, pays exclus des témoins
EVTS = [
    ("F01", "Niger–Bénin (Cotonou)", "portcalls", P("Cotonou"), "2023-08", "2024-07", ["BEN", "TGO", "NGA"]),
    ("F02", "Mer Rouge (Bab el-Mandeb)", "detroit", ["Bab el-Mandeb Strait"], "2023-12", "2024-11", None),
    ("F03", "Ormuz", "detroit", ["Strait of Hormuz"], "2026-03", "2026-09", None),
    ("F04", "Gabon (Owendo)", "portcalls", P("Port Owendo"), "2023-09", "2023-09", ["GAB"]),
    ("F05", "Mali, sanctions CEDEAO (Dakar)", "portcalls", P("Dakar"), "2022-01", "2022-07", ["SEN", "CIV", "GIN", "MRT", "TGO", "BEN"]),
    ("F06", "Mali, blocus du carburant (Dakar, pétroliers)", "portcalls_tanker", P("Dakar"), "2025-09", "2026-03", ["SEN", "CIV", "GIN", "MRT"]),
    ("F07", "Ukraine, invasion (Odessa, Tchornomorsk, Pivdennyi)", "portcalls", P("Odessa", "Chornomorsk", "Pivdennyi"), "2022-03", "2022-07", ["UKR", "ROU", "TUR"]),
    ("F08", "Ukraine, fin du corridor céréalier", "portcalls", P("Odessa", "Chornomorsk", "Pivdennyi"), "2023-08", "2024-01", ["UKR", "ROU", "TUR"]),
    ("F09", "Eilat", "portcalls", P("Eilat"), "2023-12", "2024-11", ["ISR"] + MER_ROUGE),
    ("F10", "Libye 2020 (terminaux pétroliers)", "portcalls_tanker", P("Ras Lanuf (Al Burayqah)", "Ez Zueitina", "Marsa Tobruk", "Mellitah", "Az Zawiyah"), "2020-02", "2020-09", ["LBY"]),
    ("F11", "Libye 2022 (terminaux pétroliers)", "portcalls_tanker", P("Ras Lanuf (Al Burayqah)", "Ez Zueitina", "Marsa Tobruk", "Mellitah", "Az Zawiyah"), "2022-05", "2022-07", ["LBY"]),
    ("F12", "Libye 2024 (terminaux pétroliers)", "portcalls_tanker", P("Ras Lanuf (Al Burayqah)", "Ez Zueitina", "Marsa Tobruk", "Mellitah", "Az Zawiyah"), "2024-09", "2024-09", ["LBY"]),
    ("F13", "Haïti, blocus de Varreux (Port-au-Prince, pétroliers)", "portcalls_tanker", P("Port Au Prince"), "2022-09", "2022-11", ["HTI"]),
    ("F14", "Pakistan–Afghanistan (Karachi, Port Qasim)", "portcalls", P("Karachi", "Muhammad Bin Qasim"), "2025-10", "2026-03", ["PAK"]),
    ("F15", "Port-Soudan (frappes de drones)", "portcalls", P("Port Sudan"), "2025-05", "2025-07", ["SDN"] + MER_ROUGE),
]


def chevauche(debut, fin, a, b):
    return pd.Timestamp(debut) <= pd.Timestamp(b) and pd.Timestamp(fin) >= pd.Timestamp(a)


def donneurs(ev, serie):
    """Ports/détroits témoins : pas dans les pays touchés, pas touchés par une autre fermeture au même moment."""
    _, _, typ, units, deb, fin, excl = ev
    if typ == "detroit":
        bad = {"Bab el-Mandeb Strait", "Suez Canal", "Cape of Good Hope", "Strait of Hormuz"}
        return [c for c in serie.columns if c not in bad]
    exclus = set(excl)
    if chevauche(deb, fin, "2023-11", "2026-10"): exclus |= set(MER_ROUGE)
    if chevauche(deb, fin, "2026-03", "2026-10"): exclus |= set(GOLFE)
    autres = set(u for e in EVTS if e[2] != "detroit" and chevauche(deb, fin, e[4], e[5]) for u in e[3])
    pre = serie.loc[pd.Timestamp(deb) - pd.DateOffset(months=24): pd.Timestamp(deb) - pd.DateOffset(months=1)]
    ok = pre.mean() >= 15  # séries assez actives pour être stables
    return [c for c in serie.columns if ok.get(c, False) and pays.get(c) not in exclus and c not in autres and c not in units]


def synth(y, X):
    """Poids >= 0, somme 1, qui minimisent l'écart avant la fermeture."""
    k = X.shape[1]
    f = lambda w: np.sum((y - X @ w) ** 2)
    r = minimize(f, np.ones(k) / k, method="SLSQP", bounds=[(0, 1)] * k,
                 constraints=[{"type": "eq", "fun": lambda w: w.sum() - 1}], options={"maxiter": 500})
    return r.x


def estimer(serie, units, donors, deb, fin):
    s = serie.copy()
    s["__T"] = serie[units].sum(axis=1)
    lg = np.log1p(s)
    t0 = pd.Timestamp(deb); t1 = pd.Timestamp(fin)
    pre = lg.loc[t0 - pd.DateOffset(months=24): t0 - pd.DateOffset(months=1)]
    post = lg.loc[t0:t1]
    # chaque série est centrée sur sa moyenne d'avant : on compare des évolutions, pas des tailles
    def un(col, pool):
        y0 = pre[col] - pre[col].mean(); X0 = pre[pool] - pre[pool].mean()
        w = synth(y0.values, X0.values)
        gap_pre = y0.values - X0.values @ w
        y1 = post[col] - pre[col].mean(); X1 = post[pool] - pre[pool].mean()
        gap_post = y1.values - X1.values @ w
        rmspe_pre = np.sqrt(np.mean(gap_pre ** 2)); rmspe_post = np.sqrt(np.mean(gap_post ** 2))
        return gap_post.mean(), rmspe_post / max(rmspe_pre, 1e-6), w, rmspe_pre
    eff, ratio, w, rp = un("__T", donors)
    plac = []
    for d in donors:
        pool = [c for c in donors if c != d]
        e, r, _, _ = un(d, pool)
        plac.append((e, r))
    plac = np.array(plac)
    p = (1 + np.sum(plac[:, 1] >= ratio)) / (1 + len(plac))
    top = sorted(zip(w, donors), reverse=True)[:3]
    return eff, p, ratio, rp, plac[:, 0], top


rows, placebos = [], {}
for ev in EVTS:
    eid, lab, typ, units, deb, fin, excl = ev
    serie = MD if typ == "detroit" else M[typ]
    don = donneurs(ev, serie)
    eff, p, ratio, rp, pe, top = estimer(serie, units, don, deb, fin)
    nm = (lambda c: c) if typ == "detroit" else (lambda c: nom.get(c, c))
    rows.append(dict(id=eid, fermeture=lab, indicateur="passages" if typ == "detroit" else ("escales pétroliers" if typ == "portcalls_tanker" else "escales"),
                     debut=deb, fin=fin, effet_pct=100 * (np.exp(eff) - 1), p_placebo=p, n_temoins=len(don),
                     ecart_avant_rmspe=rp, principaux_temoins="; ".join(f"{nm(c)} ({w:.0%})" for w, c in top if w > 0.01)))
    placebos[eid] = pe
    print(f"{eid} {lab:55s} effet {100*(np.exp(eff)-1):+7.1f} %  p={p:.3f}  témoins={len(don)}")

R = pd.DataFrame(rows)

# ------------------------------------------------------------------ effet groupé
eff_log = np.log1p(R.effet_pct.values / 100)
moy = eff_log.mean()
boot = [eff_log[RNG.integers(0, len(eff_log), len(eff_log))].mean() for _ in range(10000)]
lo, hi = np.percentile(boot, [2.5, 97.5])
# test de permutation groupé : on tire un placebo par fermeture, 10 000 fois
perm = np.array([np.mean([RNG.choice(placebos[e]) for e in R.id]) for _ in range(10000)])
p_grp = (1 + np.sum(perm <= moy)) / (1 + len(perm))
med = np.median(R.effet_pct)
n_neg = int((R.effet_pct < 0).sum()); n_sig = int(((R.effet_pct < 0) & (R.p_placebo <= 0.10)).sum())
print(f"\nEffet moyen des 15 fermetures : {100*(np.exp(moy)-1):+.1f} %  IC95 [{100*(np.exp(lo)-1):+.1f} ; {100*(np.exp(hi)-1):+.1f}]  p(permutation)={p_grp:.4f}")
print(f"Médiane : {med:+.1f} % | baisses : {n_neg}/15 | baisses significatives (p<=0,10) : {n_sig}/15")

# sans le cas limite F12 (crise politique libyenne 2024)
e2 = eff_log[R.id != "F12"]
print(f"Sans F12 : {100*(np.exp(e2.mean())-1):+.1f} %")
# par type
R["espace"] = R.id.map({"F01": "Frontière", "F04": "Frontière", "F05": "Frontière", "F06": "Frontière", "F14": "Frontière",
                        "F02": "Détroit / route maritime", "F03": "Détroit / route maritime", "F07": "Port / terminal",
                        "F08": "Port / terminal", "F09": "Port / terminal", "F10": "Port / terminal", "F11": "Port / terminal",
                        "F12": "Port / terminal", "F13": "Port / terminal", "F15": "Port / terminal"})
print(R.groupby("espace").effet_pct.agg(["mean", "median", "count"]).round(1).to_string())
R.round(4).to_csv(D + "generalisation_resultats.csv", index=False)
pd.DataFrame({"moyenne_log": [moy], "ic_bas": [lo], "ic_haut": [hi], "p_perm": [p_grp]}).to_csv(D + "generalisation_groupe.csv", index=False)
pd.DataFrame(dict([(k, pd.Series(v)) for k, v in placebos.items()])).to_csv(D + "generalisation_placebos.csv", index=False)
