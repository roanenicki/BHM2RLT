"""Maillon 1 généralisé : l'escalade (UCDP) précède-t-elle les fermetures ? Délai d'alerte."""
import numpy as np, pandas as pd
D='/home/claude/data/'
u=pd.read_csv(D+'ucdp_monde.csv',low_memory=False,parse_dates=['date_start'])
u=u.drop_duplicates(['date_start','latitude','longitude','best','side_a','side_b'])
EV=[('F01','Niger','2023-07-26','2023-07-30'),('F02','Yemen (North Yemen)','2023-10-07','2023-11-19'),('F03','Iran','2026-02-28','2026-03-02'),
('F05','Mali','2021-05-24','2022-01-09'),('F06','Mali','2025-09-03','2025-09-03'),('F07','Ukraine','2022-02-24','2022-02-24'),
('F08','Ukraine','2023-07-17','2023-07-17'),('F09','Israel','2023-10-07','2023-11-19'),('F10','Libya','2020-01-17','2020-01-17'),
('F11','Libya','2022-04-17','2022-04-17'),('F12','Libya','2024-08-26','2024-08-26'),('F13','Haiti','2022-09-12','2022-09-12'),
('F14','Pakistan','2025-10-12','2025-10-12'),('F15','Sudan','2025-05-04','2025-05-04')]
rows=[]
for eid,c,choc,ferm in EV:
    s=u[u.country==c].groupby(pd.Grouper(key='date_start',freq='W-SAT')).best.sum()
    s=s.reindex(pd.date_range('2018-06-30','2026-08-29',freq='W-SAT'),fill_value=0)
    f=pd.Timestamp(ferm)
    mu=s.shift(1).rolling(26,min_periods=13).mean(); sd=s.shift(1).rolling(26,min_periods=13).std()
    al=(s>mu+2*sd)&(s>0)
    w=al[(al.index>f-pd.Timedelta(weeks=12))&(al.index<=f+pd.Timedelta(days=6))]
    prem=w[w].index.min()
    avant=s[(s.index>f-pd.Timedelta(weeks=8))&(s.index<=f)].mean(); ref=s[(s.index>f-pd.Timedelta(weeks=34))&(s.index<=f-pd.Timedelta(weeks=8))].mean()
    rows.append(dict(id=eid,pays=c,date_fermeture=ferm,premiere_alerte=prem.date() if pd.notna(prem) else '',
        avance_semaines=round((f-prem).days/7,1) if pd.notna(prem) else np.nan,
        morts_par_semaine_8sem_avant=round(avant,1),morts_par_semaine_reference=round(ref,1),
        escalade=round(avant/ref,2) if ref>0 else np.nan))
R=pd.DataFrame(rows); print(R.to_string(index=False))
print('\nalerte trouvée:',R.premiere_alerte.ne('').sum(),'/',len(R),' avance médiane (sem):',R.avance_semaines.median(),' escalade médiane:',R.escalade.median())
R.to_csv(D+'generalisation_alerte.csv',index=False)
