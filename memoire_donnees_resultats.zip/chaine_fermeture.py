"""
Chaîne choc conflictuel -> fermeture -> rupture : trois cas.
Maillon 1 : l'escalade conflictuelle (ACLED) précède-t-elle la fermeture ? (signal d'alerte, délai)
Maillon 2 : la fermeture fait-elle chuter le trafic (détroits, ports) ? (avant/après, avec témoin)
"""
import numpy as np
import pandas as pd

D = "/home/claude/data/"
pd.set_option("display.width", 220)

# ------------------------------------------------------------------ données
ac = {}
for f in ["niger", "yemen", "iran"]:
    a = pd.read_csv(D + f"acled2/{f}.csv"); a["week"] = pd.to_datetime(a.week); ac[f] = a
det = pd.read_csv(D + "detroits.csv", parse_dates=["date"])
port = pd.read_csv(D + "activite.csv", parse_dates=["date"])
port["volume"] = port["import"] + port["export"]

CAS = {
    "Niger–Bénin": dict(acled="niger", fermeture="2023-07-30", choc="2023-07-26",
                         types=["Strategic developments", "Protests", "Riots"], mer=False),
    "Mer Rouge":   dict(acled="yemen", fermeture="2023-11-19", choc="2023-10-07",
                         types=["Explosions/Remote violence", "Strategic developments"], mer=True),
    "Ormuz":       dict(acled="iran", fermeture="2026-03-02", choc="2026-02-28",
                         types=["Explosions/Remote violence", "Strategic developments"], mer=False),
}

# ------------------------------------------------------------------ MAILLON 1 : alerte avant fermeture
print("=== MAILLON 1 : l'escalade précède-t-elle la fermeture ? ===")
m1 = []
for nom, c in CAS.items():
    a = ac[c["acled"]]
    sel = a[a.event_type.isin(c["types"])]
    if c["mer"]:  # Yémen : on ajoute les événements maritimes (zone 'North Indian Ocean')
        sel = pd.concat([sel, a[(a.admin1 == "North Indian Ocean") & ~a.event_type.isin(c["types"])]])
    w = sel.groupby("week").events.sum().asfreq("7D", fill_value=0)
    # signal d'alerte : semaine au-dessus de moyenne + 2 écarts-types des 26 semaines précédentes
    mu = w.shift(1).rolling(26, min_periods=13).mean(); sd = w.shift(1).rolling(26, min_periods=13).std()
    alerte = w > mu + 2 * sd
    ferm = pd.Timestamp(c["fermeture"])
    fen = alerte[(alerte.index >= ferm - pd.Timedelta(weeks=12)) & (alerte.index <= ferm)]
    prem = fen[fen].index.min()
    lead = (ferm - prem).days / 7 if pd.notna(prem) else np.nan
    base = w[(w.index >= ferm - pd.Timedelta(weeks=26)) & (w.index < ferm - pd.Timedelta(weeks=12))].mean()
    pic = w[(w.index >= ferm - pd.Timedelta(weeks=4)) & (w.index <= ferm + pd.Timedelta(weeks=1))].max()
    m1.append(dict(cas=nom, premiere_alerte=prem.date() if pd.notna(prem) else None,
                   date_fermeture=ferm.date(), avance_semaines=lead,
                   niveau_habituel=round(base, 1), pic_autour_fermeture=int(pic)))
    w.rename("evenements").to_csv(D + f"serie_conflit_{c['acled']}.csv")
M1 = pd.DataFrame(m1); print(M1.to_string(index=False))

# signal précoce plus large : Iran (troubles + développements stratégiques des 8 semaines avant)
ir = ac["iran"]; wi = ir.pivot_table(index="week", columns="event_type", values="events", aggfunc="sum", fill_value=0)
print("\nIran, 'Strategic developments' par semaine, déc. 2025 – févr. 2026 :")
print(wi.loc["2025-11-29":"2026-02-28", "Strategic developments"].to_string())

# ------------------------------------------------------------------ MAILLON 2 : fermeture -> chute du trafic
print("\n=== MAILLON 2 : la fermeture fait-elle chuter le trafic ? ===")
dm = det.groupby(["portname", pd.Grouper(key="date", freq="MS")])[["n_total", "n_tanker", "n_container", "capacity"]].sum().reset_index()


def avant_apres(serie, debut_av, fin_av, debut_ap, fin_ap):
    av = serie[debut_av:fin_av].mean(); ap = serie[debut_ap:fin_ap].mean()
    return av, ap, (ap / av - 1) * 100


m2 = []
for det_nom, cas, (a0, a1, p0, p1) in [
    ("Strait of Hormuz", "Ormuz", ("2025-09", "2026-02", "2026-03", "2026-09")),
    ("Bab el-Mandeb Strait", "Mer Rouge", ("2023-05", "2023-10", "2024-01", "2024-12")),
    ("Suez Canal", "Mer Rouge", ("2023-05", "2023-10", "2024-01", "2024-12")),
    ("Cape of Good Hope", "Mer Rouge", ("2023-05", "2023-10", "2024-01", "2024-12")),
]:
    s = dm[dm.portname == det_nom].set_index("date")
    for col in ["n_total", "n_tanker", "n_container"]:
        av, ap, pc = avant_apres(s[col], a0, a1, p0, p1)
        m2.append(dict(cas=cas, lieu=det_nom, indicateur=col, avant=round(av, 1), apres=round(ap, 1), variation_pct=round(pc, 1),
                       periode_avant=f"{a0}..{a1}", periode_apres=f"{p0}..{p1}"))

# Port de Cotonou vs Lomé (témoin) : 12 mois avant / 12 mois après la fermeture Niger-Bénin
pm = port.groupby(["portname", pd.Grouper(key="date", freq="MS")])[["portcalls", "import", "volume"]].sum().reset_index()
for pnom in ["Cotonou", "Lome"]:
    s = pm[pm.portname == pnom].set_index("date")
    for col in ["portcalls", "import"]:
        av, ap, pc = avant_apres(s[col], "2022-08", "2023-07", "2023-08", "2024-07")
        m2.append(dict(cas="Niger–Bénin", lieu=pnom, indicateur=col, avant=round(av), apres=round(ap), variation_pct=round(pc, 1),
                       periode_avant="2022-08..2023-07", periode_apres="2023-08..2024-07"))
M2 = pd.DataFrame(m2); print(M2.to_string(index=False))

# différence de différences mensuelle Cotonou - Lomé, avec IC (bootstrap par mois)
c = pm[pm.portname == "Cotonou"].set_index("date").portcalls; l = pm[pm.portname == "Lome"].set_index("date").portcalls
r = np.log(c / l)["2021-08":"2025-07"]
post = (r.index >= "2023-08-01")
dd = r[post].mean() - r[~post].mean()
rng = np.random.default_rng(42)
bs = [rng.choice(r[post].values, post.sum()).mean() - rng.choice(r[~post].values, (~post).sum()).mean() for _ in range(5000)]
lo, hi = np.percentile(bs, [2.5, 97.5])
print(f"\nCotonou vs Lomé (escales, 24 mois avant / 24 mois après) : {100*(np.exp(dd)-1):+.1f} %  IC95 [{100*(np.exp(lo)-1):+.1f} ; {100*(np.exp(hi)-1):+.1f}]")

# placebo : même calcul avec une fausse date de fermeture un an plus tôt (doit donner ~0)
r2 = np.log(c / l)["2020-08":"2023-07"]; post2 = r2.index >= "2022-08-01"
print(f"Placebo (fausse date août 2022) : {100*(np.exp(r2[post2].mean()-r2[~post2].mean())-1):+.1f} %")

# ------------------------------------------------------------------ propagation au golfe de Guinée
print("\n=== Propagation au golfe de Guinée ===")
gg = pm.groupby("date")[["portcalls"]].sum()
tk = port.groupby(pd.Grouper(key="date", freq="MS"))[["portcalls_tanker", "import_tanker"]].sum()
for lab, (p0, p1) in {"Ormuz (mars-sept. 2026 vs mêmes mois 2025)": ("2026-03", "2026-09")}.items():
    for col in ["portcalls_tanker", "import_tanker"]:
        ap = tk[col][p0:p1].mean(); av = tk[col]["2025-03":"2025-09"].mean()
        print(f"{lab} — {col} : {av:.0f} -> {ap:.0f}  ({(ap/av-1)*100:+.1f} %)")

M1.to_csv(D + "maillon1_alerte.csv", index=False); M2.to_csv(D + "maillon2_trafic.csv", index=False)
dm.to_csv(D + "detroits_mensuel.csv", index=False)
