"""Génère les tableaux des annexes A, B et C à partir des fichiers de données."""
import pandas as pd
D = "/home/claude/data/"; O = "/home/claude/memoire/src/annexes/"
esc = lambda s: str(s).replace("&", r"\&").replace("%", r"\%").replace("_", r"\_").replace("#", r"\#")

# ---------- Annexe A : inventaire détaillé
inv = pd.read_csv(D + "inventaire_fermetures_monde.csv")
res = pd.read_csv(D + "generalisation_resultats.csv").set_index("id")
cite = {"F01": "globalvoices2024,africanews2023benin", "F02": "unctad2024troubled", "F03": "windward2026",
        "F04": "channelstv2023gabon", "F05": "aljazeera2022mali", "F06": "iss2025mali", "F07": "maritimeexec2022",
        "F08": "ap2023odesa,un_blacksea_update2023", "F09": "marineinsight2025eilat", "F10": "aljazeera2020libya",
        "F11": "spglobal2022libya", "F12": "spglobal2024libya", "F13": "semafor2022haiti", "F14": "npr2026pakistan",
        "F15": "africanews2025sudan", "T1": "africanbusiness2021nigeria", "T2": "hale2021"}
L = [r"\begin{longtable}{@{}>{\raggedright\arraybackslash}p{0.6cm}>{\raggedright\arraybackslash}p{3.3cm}>{\raggedright\arraybackslash}p{2.6cm}>{\raggedright\arraybackslash}p{2.3cm}>{\raggedright\arraybackslash}p{3.0cm}>{\raggedright\arraybackslash}p{1.6cm}@{}}",
     r"\caption{Inventaire détaillé des fermetures}\label{tab:annexe-fermetures}\\", r"\toprule",
     r"\textbf{Id} & \textbf{Fermeture et choc} & \textbf{Dates (choc ; fermeture)} & \textbf{Fin} & \textbf{Unités PortWatch} & \textbf{Période mesurée} \\",
     r"\midrule\endfirsthead", r"\toprule",
     r"\textbf{Id} & \textbf{Fermeture et choc} & \textbf{Dates (choc ; fermeture)} & \textbf{Fin} & \textbf{Unités PortWatch} & \textbf{Période mesurée} \\",
     r"\midrule\endhead", r"\bottomrule\endfoot"]
for _, r in inv.iterrows():
    per = f"{res.loc[r.id,'debut']} à {res.loc[r.id,'fin']}" if r.id in res.index else "--"
    dc = "--" if pd.isna(r.date_choc) else r.date_choc
    L.append(f"{r.id} & {esc(r.fermeture)}. \\emph{{{esc(r.choc_conflictuel)}}} \\parencite{{{cite[r.id]}}} & {esc(dc)} ; {esc(r.debut_fermeture)} & {esc(r.fin_fermeture)} & {esc(r.unites_portwatch)} & {per} \\\\")
L.append(r"\end{longtable}")
open(O + "tab_fermetures.tex", "w").write("\n".join(L))

# ---------- Annexe B : 112 chocs
c = pd.read_csv(D + "chocs_retenus.csv")
nomport = {"Lome": "Lomé", "Point Noire": "Pointe-Noire", "Port De Kribi": "Kribi", "Port Gentil": "Port-Gentil", "Port Owendo": "Owendo"}
L = [r"{\footnotesize", r"\begin{longtable}{@{}rllll@{}}", r"\caption{Liste des 112 chocs retenus par l'étude d'événements}\label{tab:annexe-chocs}\\",
     r"\toprule \textbf{N\textsuperscript{o}} & \textbf{Port} & \textbf{Date} & \textbf{Règle} & \textbf{Détail} \\ \midrule\endfirsthead",
     r"\toprule \textbf{N\textsuperscript{o}} & \textbf{Port} & \textbf{Date} & \textbf{Règle} & \textbf{Détail} \\ \midrule\endhead", r"\bottomrule\endfoot"]
for _, r in c.iterrows():
    d = esc(r.detail).replace("év.", "év.")[:48]
    L.append(f"{r.n} & {nomport.get(r.port, r.port)} & {r.date} & {esc(r.type)} & {d} \\\\")
L += [r"\end{longtable}", "}"]
open(O + "tab_chocs.tex", "w").write("\n".join(L))

# ---------- Annexe C : dictionnaire
P = pd.read_csv(D + "panel_final.csv", nrows=5)
typ = {"container": "porte-conteneurs", "dry_bulk": "vraquiers", "general_cargo": "cargos généraux", "roro": "rouliers",
       "tanker": "pétroliers", "cargo": "navires de charge (hors pétroliers)"}
def desc(v):
    if v == "portid": return "Identifiant PortWatch du port", "PortWatch"
    if v == "portname": return "Nom du port", "PortWatch"
    if v == "ISO3": return "Code ISO du pays", "PortWatch"
    if v == "date": return "Mois (AAAA-MM)", "--"
    if v == "portcalls": return "Nombre d'escales du mois, tous navires", "PortWatch"
    if v.startswith("portcalls_"): return f"Escales du mois : {typ[v[10:]]}", "PortWatch"
    if v == "import": return "Volume importé estimé (tonnes)", "PortWatch"
    if v == "export": return "Volume exporté estimé (tonnes)", "PortWatch"
    if v.startswith("import_"): return f"Volume importé : {typ[v[7:]]}", "PortWatch"
    if v.startswith("export_"): return f"Volume exporté : {typ[v[7:]]}", "PortWatch"
    if v == "volume": return "Importations + exportations (tonnes)", "PortWatch"
    if v == "rupture": return "Rupture générale au mois $t$ (équation~\\ref{eq:rupture})", "Calculée"
    if v == "rupture_petrole": return "Rupture pétrolière : escales de pétroliers $<0{,}7\\times$ médiane des 12 mois passés", "Calculée"
    if v == "rupture_conteneurs": return "Rupture conteneurs : escales de porte-conteneurs $<0{,}7\\times$ médiane", "Calculée"
    if v.endswith("_t+1"): return f"Cible : {v.replace('_t+1','').replace('_',' ')} au mois $t+1$", "Calculée"
    if v == "ecart_escales": return "Escales rapportées à leur médiane des 12 mois passés, moins 1", "Calculée"
    if v == "ecart_volume": return "Volume rapporté à sa médiane des 12 mois passés, moins 1", "Calculée"
    if v.startswith("ucdp_ev_"): return f"Événements UCDP à moins de {v.split('_')[-1].replace('km',' km')}", "UCDP"
    if v.startswith("ucdp_morts_"): return f"Morts (estimation centrale) à moins de {v.split('_')[-1].replace('km',' km')}", "UCDP"
    if v == "ucdp_etat_100km": return "Événements de violence étatique à moins de 100 km", "UCDP"
    if v == "ucdp_nonetat_100km": return "Événements de violence non étatique à moins de 100 km", "UCDP"
    if v == "ucdp_unilaterale_100km": return "Événements de violence unilatérale à moins de 100 km", "UCDP"
    if v == "ucdp_provisoire": return "1 si le mois est couvert par les données UCDP provisoires (2026)", "UCDP"
    acl = {"acled_combats": "Combats", "acled_emeutes": "Émeutes", "acled_manifestations": "Manifestations",
           "acled_strategique": "Développements stratégiques", "acled_violence_civils": "Violence contre les civils",
           "acled_explosions": "Explosions et violence à distance", "acled_morts": "Morts"}
    if v in acl: return f"{acl[v]}, régions à moins de 150 km", "ACLED"
    if v.startswith("pirat_incidents"): return f"Incidents de piraterie à moins de {v.split('_')[-1].replace('km',' km')}", "OMI"
    if v.startswith("pirat_enlevements"): return f"Incidents avec enlèvement à moins de {v.split('_')[-1].replace('km',' km')}", "OMI"
    if v == "brent_moy": return "Prix moyen du Brent dans le mois (USD)", "FRED"
    if v == "brent_vol": return "Écart-type du prix quotidien du Brent dans le mois", "FRED"
    if v == "brent_var_1m": return "Variation du prix moyen du Brent sur un mois", "FRED"
    if v == "ocde_risque_pays": return "Note de risque pays OCDE (0 à 7) en vigueur", "OCDE"
    if v == "annee": return "Année", "--"
    if v == "sipri_import_armes": return "Importations d'armes de l'année précédente (TIV)", "SIPRI"
    if v == "sipri_depmil_pib": return "Dépenses militaires de l'année précédente (\\% du PIB)", "SIPRI"
    if v == "covid_restrictions": return "Indice de sévérité des restrictions sanitaires", "OxCGRT"
    if v == "covid_frontieres": return "Contrôles aux frontières (échelle OxCGRT)", "OxCGRT"
    if v == "port_part_petroliers": return "Part des pétroliers dans les navires du port", "PortWatch"
    if v == "port_part_import_pays": return "Part du port dans les importations maritimes du pays", "PortWatch"
    if v == "mois": return "Mois de l'année (1 à 12)", "--"
    raise KeyError(v)
L = [r"{\footnotesize", r"\begin{longtable}{@{}>{\raggedright\arraybackslash}p{4.4cm}>{\raggedright\arraybackslash}p{8.4cm}l@{}}",
     r"\caption{Dictionnaire des variables du panel port $\times$ mois}\label{tab:annexe-dico}\\",
     r"\toprule \textbf{Variable} & \textbf{Description} & \textbf{Source} \\ \midrule\endfirsthead",
     r"\toprule \textbf{Variable} & \textbf{Description} & \textbf{Source} \\ \midrule\endhead", r"\bottomrule\endfoot"]
for v in P.columns:
    d, s = desc(v)
    L.append(f"\\texttt{{{esc(v)}}} & {d} & {s} \\\\")
L += [r"\end{longtable}", "}"]
open(O + "tab_dictionnaire.tex", "w").write("\n".join(L))
print("ok", len(P.columns))
