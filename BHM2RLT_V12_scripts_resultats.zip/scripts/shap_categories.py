import sys; sys.argv=['x']
exec(open('/home/claude/scripts/variantes.py').read().split("MOD=[")[0])
import shap
from xgboost import XGBClassifier
from sklearn.ensemble import RandomForestClassifier
cible='rupture_t+1'; feats=list(BASE)+IDX
def cat(f):
    if f.startswith('idx_violence_armee'): return 'UCDP'
    if f=='idx_troubles_sociaux_rel': return 'troubles'
    if f=='idx_violence_acled_rel': return 'violence acled'
    if f=='idx_piraterie': return 'piraterie'
    if f.startswith('brent'): return 'Brent'
    if f.startswith('covid'): return 'Covid'
    if f.startswith(('ocde','sipri')): return 'Contexte'
    if f.startswith('port_'): return 'Profil'
    if f=='mois': return 'Saison'
    return 'Etat'
for per in ['<2026','all']:
    D=P.dropna(subset=[cible]); 
    if per=='<2026': D=D[D.date<'2026-01-01']
    X=D[feats].fillna(D[feats].median()); y=D[cible]; pr=y.mean()
    for nom,mdl in [('XGB',XGBClassifier(n_estimators=300,max_depth=3,learning_rate=0.05,subsample=0.8,colsample_bytree=0.7,min_child_weight=5,reg_lambda=1.0,scale_pos_weight=(1-pr)/pr,random_state=42,verbosity=0)),
                    ('RF',RandomForestClassifier(n_estimators=400,min_samples_leaf=10,max_features='sqrt',class_weight='balanced_subsample',random_state=42,n_jobs=-1))]:
        mdl.fit(X,y); sv=shap.TreeExplainer(mdl).shap_values(X)
        if isinstance(sv,list): sv=sv[1]
        if sv.ndim==3: sv=sv[:,:,1]
        imp=pd.Series(np.abs(sv).mean(0),index=feats); c=imp.groupby(imp.index.map(cat)).sum()
        print(per,nom,(100*c/c.sum()).round(2).to_dict())
