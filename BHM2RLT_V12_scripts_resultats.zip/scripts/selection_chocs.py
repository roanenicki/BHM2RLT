"""
Étude d'événements — Étape 1 : sélection des gros chocs (règles fixées AVANT toute mesure d'impact).

RÈGLES (pré-enregistrées, ne pas modifier après avoir vu les résultats) :
R1 Violence armée (UCDP) : un jour où les morts (estimation 'best') d'événements localisés
   (précision <= 3) à moins de 100 km d'un port totalisent >= 10.
R2 Troubles sociaux (ACLED, données hebdomadaires) : une semaine où émeutes + manifestations
   dans les régions à moins de 150 km d'un port dépassent le 95e percentile de la série du port
   (calculé sur 2019-2026) ET >= 10 événements. Date du choc = début de semaine.
R3 Violence ACLED (combats + violences contre civils + explosions) : même règle que R2.
R4 Piraterie (OMI) : incident à moins de 100 km d'un port avec enlèvement / prise d'otages.
Fenêtre : de 30 jours avant à 60 jours après le choc (activité quotidienne PortWatch).
Dédoublonnage : pour un même port, un choc n'est retenu que s'il survient plus de 60 jours
   après le précédent choc retenu (tous types confondus) ; à date égale, priorité R1>R4>R3>R2.
Période : chocs entre le 1er mars 2019 et le 31 juillet 2026 (fenêtre complète disponible).
Comparaison : les mêmes jours calendaires, dans les ports sans aucun choc retenu à +/- 60 jours.
"""
import glob
import numpy as np
import pandas as pd

D = "/home/claude/data/"


def dist(lat1, lon1, lat2, lon2):
    lat1, lon1, lat2, lon2 = map(np.radians, [lat1, lon1, lat2, lon2])
    a = np.sin((lat2 - lat1) / 2) ** 2 + np.cos(lat1) * np.cos(lat2) * np.sin((lon2 - lon1) / 2) ** 2
    return 2 * 6371 * np.arcsin(np.sqrt(a))


panel = pd.read_csv(D + "panel_final.csv")
ports = pd.read_csv(D + "ports.csv").set_index("portid").loc[panel.portid.unique()]

u = pd.read_csv(D + "ucdp.csv", low_memory=False, parse_dates=["date_start"])
u = u.drop_duplicates(["date_start", "latitude", "longitude", "best", "side_a", "side_b"])
u = u[u.where_prec <= 3]
a = pd.concat([pd.read_csv(f) for f in glob.glob(D + "acled/*.csv")]).drop_duplicates()
a["week"] = pd.to_datetime(a.week)
p = pd.read_csv(D + "imo_piraterie.csv", parse_dates=["Date"]).dropna(subset=["lat"])
p["enl"] = p["Consequences for crew etc"].astype(str).str.contains("kidnap|hostage", case=False)

cand = []
for pid, pt in ports.iterrows():
    # R1
    du = dist(pt.lat, pt.lon, u.latitude.values, u.longitude.values)
    s = u[du <= 100].groupby("date_start").agg(morts=("best", "sum"), n=("id", "size"),
                                                 acteurs=("side_b", lambda x: "; ".join(sorted(set(map(str, x)))[:2])))
    for d, r in s[s.morts >= 10].iterrows():
        cand.append((pid, pt.portname, d, "R1 Violence armée", f"{int(r.morts)} morts, {r.n} év. — {r.acteurs}", 1))
    # R2 / R3
    da = dist(pt.lat, pt.lon, a.centroid_latitude.values, a.centroid_longitude.values)
    w = a[da <= 150].pivot_table(index="week", columns="event_type", values="events", aggfunc="sum", fill_value=0)
    for col in ["Riots", "Protests", "Battles", "Violence against civilians", "Explosions/Remote violence"]:
        if col not in w: w[col] = 0
    soc = w["Riots"] + w["Protests"]
    vio = w["Battles"] + w["Violence against civilians"] + w["Explosions/Remote violence"]
    for serie, lab, prio in [(vio, "R3 Violence (ACLED)", 3), (soc, "R2 Troubles sociaux", 4)]:
        seuil = max(serie.quantile(0.95), 10)
        for d, v in serie[serie >= seuil].items():
            cand.append((pid, pt.portname, d, lab, f"{int(v)} év./semaine (seuil {seuil:.0f})", prio))
    # R4
    dp = dist(pt.lat, pt.lon, p.lat.values, p.lon.values)
    for _, r in p[(dp <= 100) & p.enl].iterrows():
        cand.append((pid, pt.portname, r.Date, "R4 Piraterie (enlèvement)", str(r["Ship Name"]), 2))

C = pd.DataFrame(cand, columns=["portid", "port", "date", "type", "detail", "prio"])
C = C[(C.date >= "2019-03-01") & (C.date <= "2026-07-31")].sort_values(["portid", "date", "prio"])

# dédoublonnage : 60 jours minimum entre deux chocs retenus d'un même port
retenus = []
for pid, g in C.groupby("portid"):
    last = None
    for _, r in g.iterrows():
        if last is None or (r.date - last).days > 60:
            retenus.append(r); last = r.date
R = pd.DataFrame(retenus).sort_values("date").reset_index(drop=True)
R.index += 1
C.to_csv(D + "chocs_candidats.csv", index=False)
R.to_csv(D + "chocs_retenus.csv", index_label="n")
print("Candidats :", len(C), "| retenus après dédoublonnage :", len(R))
print(R.groupby("type").size().to_string())
print(R.groupby("port").size().sort_values(ascending=False).to_string())
pd.set_option("display.width", 250); pd.set_option("display.max_colwidth", 70)
print(R[["port", "date", "type", "detail"]].assign(date=R.date.dt.strftime("%Y-%m-%d")).to_string())
