import pandas as pd, numpy as np, glob
D='/home/claude/data/'
R=6371
def dist(lat1,lon1,lat2,lon2):
    lat1,lon1,lat2,lon2=map(np.radians,[lat1,lon1,lat2,lon2])
    a=np.sin((lat2-lat1)/2)**2+np.cos(lat1)*np.cos(lat2)*np.sin((lon2-lon1)/2)**2
    return 2*R*np.arcsin(np.sqrt(a))
# --- Y
d=pd.read_csv(D+'activite.csv',parse_dates=['date']); d=d[d.date<'2026-10-01']
m=d.groupby(['portid','portname',pd.Grouper(key='date',freq='MS')])[['portcalls','import','export']].sum().reset_index()
m['vol']=m['import']+m['export']
keep=m.groupby('portid').portcalls.mean(); m=m[m.portid.isin(keep[keep>=15].index)].copy()
def lab(g):
    bc=g.portcalls.shift(1).rolling(12,min_periods=6).median(); bv=g.vol.shift(1).rolling(12,min_periods=6).median()
    g['rupture']=((g.portcalls<0.8*bc)|(g.vol<0.7*bv)).astype(int); g.loc[bc.isna(),'rupture']=np.nan; return g
m=pd.concat([lab(g.copy()) for _,g in m.sort_values(['portid','date']).groupby('portid')])
ports=pd.read_csv(D+'ports.csv').set_index('portid')
# --- UCDP
u=pd.read_csv(D+'ucdp.csv',low_memory=False,parse_dates=['date_start'])
u=u.drop_duplicates(['date_start','latitude','longitude','best','side_a','side_b'])
u=u[u.where_prec<=3]
u['mois']=u.date_start.dt.to_period('M').dt.to_timestamp()
# --- ACLED
a=pd.concat([pd.read_csv(f) for f in glob.glob(D+'acled/*.csv')]).drop_duplicates()
a['mois']=pd.to_datetime(a.week).dt.to_period('M').dt.to_timestamp()
rows=[]
for pid,p in ports.loc[m.portid.unique()].iterrows():
    du=dist(p.lat,p.lon,u.latitude.values,u.longitude.values)
    da=dist(p.lat,p.lon,a.centroid_latitude.values,a.centroid_longitude.values)
    for rad in [100,250]:
        s=u[du<=rad].groupby('mois').agg(ev=('id','size'),morts=('best','sum'))
        s.columns=[f'ucdp_{c}_{rad}' for c in s.columns]; s['portid']=pid; rows.append(s.reset_index())
    s=a[da<=200].pivot_table(index='mois',columns='event_type',values='events',aggfunc='sum',fill_value=0)
    s.columns=['acled_'+c.split('/')[0].split(' ')[0].lower() for c in s.columns]; s['portid']=pid; rows.append(s.reset_index())
X=pd.concat(rows).groupby(['portid','mois']).sum().reset_index().rename(columns={'mois':'date'})
P=m.merge(X,on=['portid','date'],how='left').fillna(0).sort_values(['portid','date'])
P['y_next']=P.groupby('portid').rupture.shift(-1)
feats=[c for c in P.columns if c.startswith(('ucdp_','acled_'))]
P.to_csv('/home/claude/data/panel_test.csv',index=False)
print('obs',len(P),'ports',P.portid.nunique())
print('\nTaux de rupture au mois t+1 selon le choc au mois t (choc = au-dessus de la mediane 12 mois passes du port)')
for f in feats:
    base=P.groupby('portid')[f].transform(lambda s:s.shift(1).rolling(12,min_periods=6).median())
    hi=(P[f]>base)&(P[f]>0)
    ok=P.y_next.notna()&base.notna()
    r1=P.loc[ok&hi,'y_next'].mean(); r0=P.loc[ok&~hi,'y_next'].mean()
    print(f'{f:28s} choc:{r1:.3f} (n={int((ok&hi).sum())})  pas de choc:{r0:.3f}  ratio {r1/r0:.2f}')
