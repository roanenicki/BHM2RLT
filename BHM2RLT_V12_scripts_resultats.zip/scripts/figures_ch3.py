"""Figures du chapitre 3 (format mémoire : pas de titre dans l'image, la légende LaTeX le porte)."""
import numpy as np, pandas as pd, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from PIL import Image
D = "/home/claude/data/"; O = "/home/claude/memoire/src/figures/ch3/"
BLEU, GRIS, ENCRE, MUET = "#2a78d6", "#bfbdb6", "#2b2b2b", "#6b6b6b"
plt.rcParams.update({"font.family": "Inter", "font.size": 10, "axes.edgecolor": ENCRE, "axes.labelcolor": ENCRE,
                     "xtick.color": ENCRE, "ytick.color": ENCRE, "axes.spines.top": False, "axes.spines.right": False})

# 1) SHAP par catégorie
s = pd.read_csv(D + "shap_categories_rf_indices.csv", index_col=0).part_pct.sort_values()
fig, ax = plt.subplots(figsize=(7.2, 3.9))
col = [BLEU if i.startswith("Chocs") else GRIS for i in s.index]
ax.barh(s.index, s.values, color=col, height=0.62)
for y, v in enumerate(s.values):
    ax.text(v + 0.6, y, f"{v:.1f} %".replace(".", ","), va="center", fontsize=9, color=ENCRE)
ax.set_xlabel("Part de l'importance totale (moyenne des |valeurs SHAP|, %)")
ax.set_xlim(0, 46); ax.grid(axis="x", color="#e6e6e6", lw=0.6); ax.set_axisbelow(True)
ax.tick_params(axis="y", length=0)
fig.tight_layout(); fig.savefig(O + "fig_shap.png", dpi=220); plt.close()

# 2) Généralisation : 15 effets
R = pd.read_csv(D + "generalisation_resultats.csv").sort_values("effet_pct", ascending=False)
g = pd.read_csv(D + "generalisation_groupe.csv").iloc[0]
moy, lo, hi = [100 * (np.exp(g[k]) - 1) for k in ("moyenne_log", "ic_bas", "ic_haut")]
court = {"F01": "Niger–Bénin (Cotonou)", "F02": "Mer Rouge (Bab el-Mandeb)", "F03": "Ormuz", "F04": "Gabon (Owendo)",
         "F05": "Mali, sanctions CEDEAO (Dakar)", "F06": "Mali, blocus du carburant (Dakar)", "F07": "Ukraine, invasion (ports)",
         "F08": "Ukraine, fin du corridor céréalier", "F09": "Eilat", "F10": "Libye 2020 (terminaux)", "F11": "Libye 2022 (terminaux)",
         "F12": "Libye 2024 (terminaux)", "F13": "Haïti, terminal de Varreux", "F14": "Pakistan–Afghanistan (Karachi)", "F15": "Port-Soudan"}
fig, ax = plt.subplots(figsize=(7.6, 6.0))
ax.axvspan(lo, hi, color=BLEU, alpha=0.08, lw=0)
ax.axvline(moy, color=BLEU, ls="--", lw=1.2)
y = np.arange(len(R))
sig = (R.p_placebo <= 0.10) & (R.effet_pct < 0)
ax.barh(y, R.effet_pct, color=np.where(sig, BLEU, GRIS), height=0.62)
for yi, (v, p) in enumerate(zip(R.effet_pct, R.p_placebo)):
    ax.text(15, yi, f"{v:+.0f} %".replace(".", ","), va="center", ha="right", fontsize=8.4, color=ENCRE)
    ax.text(18, yi, f"p = {p:.2f}".replace(".", ","), va="center", ha="left", fontsize=8.4, color=MUET)
ax.set_yticks(y, [f"{i}  {court[i]}" for i in R.id], fontsize=8.6)
ax.axvline(0, color=ENCRE, lw=0.8)
ax.set_xlim(-102, 38); ax.set_ylim(len(R) - 0.4, -1.6)
ax.set_xticks(range(-100, 1, 20))
ax.text(moy, -1.05, f"effet moyen : {moy:.0f} %  (IC 95 % : {lo:.0f} à {hi:.0f})".replace(".", ","), color=BLEU,
        ha="center", va="center", fontsize=8.5)
ax.set_xlabel("Écart du trafic par rapport au contrôle synthétique pendant la fermeture (%)")
ax.grid(axis="x", color="#e6e6e6", lw=0.6); ax.set_axisbelow(True); ax.tick_params(axis="y", length=0)
fig.tight_layout(); fig.savefig(O + "fig_generalisation.png", dpi=220); plt.close()

# 3) Effet par type de maillon
order = ["Détroit / route maritime", "Port / terminal", "Frontière"]
lab = {"Détroit / route maritime": "Détroit\n(n = 2)", "Port / terminal": "Port ou terminal\n(n = 8)", "Frontière": "Frontière terrestre\n(n = 5)"}
fig, ax = plt.subplots(figsize=(7.0, 2.9))
rng = np.random.default_rng(1)
for k, e in enumerate(order):
    v = R[R.espace == e].effet_pct.values
    yy = k + rng.uniform(-0.12, 0.12, len(v))
    ax.scatter(v, yy, s=46, color=BLEU, alpha=0.55, edgecolor="white", lw=1, zorder=3)
    m = v.mean()
    ax.plot([m, m], [k - 0.3, k + 0.3], color=ENCRE, lw=2.2, zorder=4)
    ax.text(m + 1.5, k - 0.27, f"moyenne {m:.0f} %".replace(".", ","), ha="left", va="center", fontsize=8.5, color=ENCRE)
ax.set_yticks(range(3), [lab[e] for e in order]); ax.invert_yaxis()
ax.axvline(0, color=ENCRE, lw=0.8); ax.set_xlim(-105, 12); ax.set_ylim(2.65, -0.65)
ax.set_xlabel("Effet de la fermeture sur le trafic (%)"); ax.grid(axis="x", color="#e6e6e6", lw=0.6); ax.set_axisbelow(True)
ax.tick_params(axis="y", length=0)
fig.tight_layout(); fig.savefig(O + "fig_types.png", dpi=220); plt.close()

# 4) Figures existantes : on retire le titre intégré à l'image
for src, dst, top in [("/home/claude/figure_etude_evenements.png", "fig_etude_evenements.png", 95),
                      ("/home/claude/figure_chaine_fermeture.png", "fig_trois_cas.png", 95)]:
    im = Image.open(src); w, h = im.size; im.crop((0, top, w, h)).save(O + dst)
print("ok")
