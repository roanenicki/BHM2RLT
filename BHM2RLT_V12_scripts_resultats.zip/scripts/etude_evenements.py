"""
Étude d'événements — Étape 2 : mesure de l'impact des gros chocs sur l'activité portuaire.

Méthode (différence de différences autour de chaque choc) :
- Activité quotidienne du port, regroupée par semaines relatives au choc (semaine -4 à +8).
- Variable : log(1 + activité de la semaine).
- Pour chaque choc : écart par rapport à la moyenne des 4 semaines AVANT le choc,
  MOINS le même écart calculé, aux mêmes dates, pour les ports témoins
  (ports sans choc retenu dans les 60 jours avant / après).
- Moyenne sur tous les chocs ; intervalle de confiance à 95 % par bootstrap,
  en tirant des DATES de choc (les chocs simultanés de ports voisins restent groupés).
"""
import numpy as np
import pandas as pd

D = "/home/claude/data/"
RNG = np.random.default_rng(42)

act = pd.read_csv(D + "activite.csv", parse_dates=["date"])
chocs = pd.read_csv(D + "chocs_retenus.csv", parse_dates=["date"])
ports18 = chocs.portid.unique().tolist() + [p for p in pd.read_csv(D + "panel_final.csv").portid.unique()
                                            if p not in chocs.portid.unique()]
ports18 = list(dict.fromkeys(ports18))
act = act[act.portid.isin(ports18)].copy()
act["volume"] = act["import"] + act["export"]
OUT = {"escales": "portcalls", "volume": "volume", "escales_petroliers": "portcalls_tanker",
       "escales_conteneurs": "portcalls_container"}
S = {k: act.pivot_table(index="date", columns="portid", values=v, aggfunc="sum") for k, v in OUT.items()}

# ports "occupés" (choc retenu) : jours à +/- 60 du choc
occupe = {p: set() for p in ports18}
for _, c in chocs.iterrows():
    for d in pd.date_range(c.date - pd.Timedelta(days=60), c.date + pd.Timedelta(days=60)):
        occupe[c.portid].add(d)

SEM = list(range(-4, 9))  # semaines relatives
rows = []
for i, c in chocs.iterrows():
    t0 = c.date.normalize()
    jours = pd.date_range(t0 - pd.Timedelta(days=28), t0 + pd.Timedelta(days=62))
    if jours.max() > act.date.max():
        continue
    sem = ((jours - t0).days // 7)
    temoins = [p for p in ports18 if p != c.portid and not any(d in occupe[p] for d in (t0, t0 - pd.Timedelta(days=30), t0 + pd.Timedelta(days=30)))]
    for k, M in S.items():
        tr = M.loc[jours, c.portid]
        if tr.sum() == 0 or (k != "escales" and M[c.portid].mean() < 0.3):  # flux quasi inexistant dans ce port
            continue
        ctl = M.loc[jours, temoins]
        ctl = ctl.loc[:, ctl.mean() >= 0.3]
        trw = np.log1p(tr.groupby(sem.values).sum())
        ctw = np.log1p(ctl.groupby(sem.values).sum())
        trw = trw - trw.loc[-4:-1].mean()
        ctw = (ctw - ctw.loc[-4:-1].mean()).mean(axis=1)
        ab = (trw - ctw).reindex(SEM)
        for s, v in ab.items():
            rows.append({"choc": i, "port": c.port, "date_choc": t0, "type": c.type, "indicateur": k,
                         "semaine": s, "ecart_anormal": v})
E = pd.DataFrame(rows).dropna()
E.to_csv(D + "etude_evenements_detail.csv", index=False)


def resume(df, label):
    """Effet moyen par fenêtre, avec IC95 bootstrap par date de choc."""
    fen = {"semaines 0-1": (0, 1), "semaines 2-3": (2, 3), "semaines 4-8": (4, 8), "avant (-4 à -1, contrôle)": (-4, -1)}
    ev = df.pivot_table(index=["choc", "date_choc"], columns="semaine", values="ecart_anormal")
    dates = ev.index.get_level_values("date_choc").unique()
    out = []
    for nom, (a, b) in fen.items():
        val = ev.loc[:, a:b].mean(axis=1)
        est = val.mean()
        gd = val.groupby(level="date_choc").agg(["sum", "count"])
        sm, ct = gd["sum"].values, gd["count"].values
        idx = RNG.integers(0, len(gd), size=(2000, len(gd)))
        boots = sm[idx].sum(1) / ct[idx].sum(1)
        lo, hi = np.percentile(boots, [2.5, 97.5])
        out.append({"groupe": label, "fenêtre": nom, "effet_%": 100 * (np.exp(est) - 1),
                    "IC95_bas_%": 100 * (np.exp(lo) - 1), "IC95_haut_%": 100 * (np.exp(hi) - 1),
                    "significatif": "oui" if (lo > 0 or hi < 0) else "non", "n_chocs": len(val), "n_dates": len(dates)})
    return out


res = []
for k in OUT:
    res += resume(E[E.indicateur == k], f"Tous les chocs — {k}")
for t in sorted(E.type.unique()):
    for k in ["escales", "volume"]:
        sub = E[(E.type == t) & (E.indicateur == k)]
        if sub.choc.nunique() >= 8:
            res += resume(sub, f"{t} — {k}")
R = pd.DataFrame(res)
R.to_csv(D + "etude_evenements_resultats.csv", index=False)
pd.set_option("display.width", 250)
print(R.round(1).to_string(index=False))

# profil semaine par semaine (pour le graphique)
prof = E.groupby(["indicateur", "semaine"]).ecart_anormal.agg(["mean", "sem", "count"]).reset_index()
prof["effet_%"] = 100 * (np.exp(prof["mean"]) - 1)
prof["bas_%"] = 100 * (np.exp(prof["mean"] - 1.96 * prof["sem"]) - 1)
prof["haut_%"] = 100 * (np.exp(prof["mean"] + 1.96 * prof["sem"]) - 1)
prof.to_csv(D + "etude_evenements_profil.csv", index=False)
