import numpy as np, pandas as pd, statsmodels.api as sm
a=pd.read_csv('/home/claude/data/activite.csv',parse_dates=['date']); a=a[a.date<'2026-10-01']
m=a.pivot_table(index=pd.Grouper(key='date',freq='MS'),columns='portname',values='portcalls',aggfunc='sum')
def its(ctrl,deb='2019-01-01',fin='2025-07-01',post0='2023-08-01'):
    y=np.log(m['Cotonou'])-np.log(m[ctrl].sum(1) if isinstance(ctrl,list) else m[ctrl])
    y=y[deb:fin]; t=np.arange(len(y)); post=(y.index>=post0).astype(float)
    X=sm.add_constant(np.column_stack([t,post])); r=sm.OLS(y.values,X).fit(cov_type='HAC',cov_kwds={'maxlags':6})
    b=r.params[2]; lo,hi=r.conf_int()[2]
    return 100*(np.exp(b)-1),100*(np.exp(lo)-1),100*(np.exp(hi)-1),r.pvalues[2], 100*(np.exp(12*r.params[1])-1)
gg=['Abidjan','Bata','Douala','Malabo','Point Noire','Port De Kribi','Port Gentil','Port Owendo','San Pedro','Takoradi','Tema']
print('Lome', np.round(its('Lome'),3))
for nm,c in [('11 ports non NGA/TGO',gg),('9 sans Bata/Malabo',[p for p in gg if p not in ('Bata','Malabo')]),('9 sans SanPedro/Takoradi',[p for p in gg if p not in ('San Pedro','Takoradi')])]:
    print(nm, np.round(its(c),3))
for deb in ['2020-01-01','2021-08-01']:
    print('Lome deb',deb,np.round(its('Lome',deb),3))
print('--- moyenne des log (poids égaux)')
def its2(ctrls,deb='2019-01-01',fin='2025-07-01',post0='2023-08-01'):
    y=np.log(m['Cotonou'])-np.log(m[ctrls]).mean(axis=1)
    y=y[deb:fin]; t=np.arange(len(y)); post=(y.index>=post0).astype(float)
    r=sm.OLS(y.values,sm.add_constant(np.column_stack([t,post]))).fit(cov_type='HAC',cov_kwds={'maxlags':6})
    lo,hi=r.conf_int()[2]; return [round(100*(np.exp(v)-1),1) for v in (r.params[2],lo,hi)]+[round(r.pvalues[2],3)]
big=['Abidjan','Douala','Point Noire','Port Owendo','San Pedro','Takoradi','Tema','Port De Kribi','Port Gentil']
for deb in ['2019-01-01','2020-01-01','2021-08-01']:
    print(deb,'9 ports',its2(big,deb),' lome',its2(['Lome'],deb), '10 (9+Lome)', its2(big+['Lome'],deb))
