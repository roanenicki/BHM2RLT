"""Annexe D : trajectoires de l'unité fermée et de son contrôle synthétique (15 fermetures)."""
import numpy as np, pandas as pd, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
src = open("/home/claude/scripts/controle_synthetique.py").read().split("rows, placebos = [], {}")[0]
exec(src)
BLEU, GRIS, ENCRE = "#2a78d6", "#8f8d86", "#2b2b2b"
plt.rcParams.update({"font.family": "Inter", "font.size": 7.5, "axes.spines.top": False, "axes.spines.right": False})
R = pd.read_csv(D + "generalisation_resultats.csv").set_index("id")
fig, axes = plt.subplots(5, 3, figsize=(7.4, 9.6))
for ax, ev in zip(axes.flat, EVTS):
    eid, lab, typ, units, deb, fin, excl = ev
    serie = MD if typ == "detroit" else M[typ]
    don = donneurs(ev, serie)
    s = serie.copy(); s["__T"] = serie[units].sum(axis=1); lg = np.log1p(s)
    t0, t1 = pd.Timestamp(deb), pd.Timestamp(fin)
    pre = lg.loc[t0 - pd.DateOffset(months=24): t0 - pd.DateOffset(months=1)]
    win = lg.loc[t0 - pd.DateOffset(months=24): min(t1 + pd.DateOffset(months=6), lg.index.max())]
    y0 = pre["__T"] - pre["__T"].mean(); X0 = pre[don] - pre[don].mean()
    w = synth(y0.values, X0.values)
    yt = win["__T"] - pre["__T"].mean(); ys = (win[don] - pre[don].mean()).values @ w
    ax.axvspan(t0, t1 + pd.offsets.MonthEnd(0), color=BLEU, alpha=0.08, lw=0)
    ax.plot(win.index, 100 * np.exp(ys), color=GRIS, lw=1.2, ls="--", label="synthétique")
    ax.plot(win.index, 100 * np.exp(yt), color=BLEU, lw=1.4, label="unité fermée")
    ax.axhline(100, color=ENCRE, lw=0.4)
    e = R.loc[eid, "effet_pct"]; p = R.loc[eid, "p_placebo"]
    ax.set_title(f"{eid} {lab.split(' (')[0]}", fontsize=7.6, loc="left", color=ENCRE)
    ax.text(0.02, 0.05, f"effet {e:+.0f} %, p = {p:.2f}".replace(".", ","), transform=ax.transAxes, fontsize=6.8, color=ENCRE, bbox=dict(facecolor="white", edgecolor="none", alpha=0.9, pad=1.2), zorder=5)
    ax.tick_params(labelsize=6.3); ax.xaxis.set_major_locator(matplotlib.dates.YearLocator())
    ax.xaxis.set_major_formatter(matplotlib.dates.DateFormatter("%Y"))
axes.flat[0].legend(fontsize=6.5, frameon=False, loc="lower left", bbox_to_anchor=(0, 0.12))
fig.supylabel("Trafic (indice 100 = moyenne des 24 mois avant la fermeture)", fontsize=7.5)
fig.tight_layout(); fig.savefig("/home/claude/memoire/src/figures/ch3/fig_annexe_trajectoires.png", dpi=220)
print("ok")
