import sys; sys.argv=['x']
exec(open('/home/claude/scripts/modeliser.py').read().split('if __name__')[0])
# Indices de chocs synthétiques par catégorie (peu de variables, moins de bruit)
g=P.groupby('portid')
def rel(s): m=s.shift(1).rolling(12,min_periods=6).mean(); return (s-m)/(m+1)
P['idx_violence_armee']=P['ucdp_ev_100km_cum3']
P['idx_violence_armee_morts']=np.log1p(P['ucdp_morts_100km_cum3'])
P['idx_troubles_sociaux_rel']=g.apply(lambda d: rel(d.acled_emeutes+d.acled_manifestations)).reset_index(level=0,drop=True)
P['idx_violence_acled_rel']=g.apply(lambda d: rel(d.acled_combats+d.acled_violence_civils+d.acled_explosions)).reset_index(level=0,drop=True)
P['idx_piraterie']=P['pirat_incidents_100km_cum3']
IDX=['idx_violence_armee','idx_violence_armee_morts','idx_troubles_sociaux_rel','idx_violence_acled_rel','idx_piraterie']
P[IDX]=P[IDX].replace([np.inf,-np.inf],np.nan)
MOD=["Régression logistique","Random Forest","XGBoost"]
cible='rupture_t+1'; base=[f for f in BASE]
expo=P.groupby('portname').ucdp_ev_100km.sum(); expo=expo[expo>=30].index.tolist()
for nom,filtre in [('18 ports',None),('8 ports exposés',expo)]:
    Q=P if filtre is None else P[P.portname.isin(filtre)]
    globals()['P_full']=P
    import builtins
    P_save=P; globals()['P']=Q.copy()
    ra=walk_forward(cible,base); rb=walk_forward(cible,base+IDX)
    globals()['P']=P_save
    print(f'\n### {nom} — indices synthétiques (n={len(ra)}, taux={ra[cible].mean():.3f})')
    print(pd.concat([scores(ra,cible,MOD).assign(v='A sans'),scores(rb,cible,MOD).assign(v='B avec')])[['modèle','v','PR-AUC','ROC-AUC','Rappel','Précision']].round(3).to_string(index=False))
    for m in MOD:
        ci,pp=boot_diff(ra,rb,cible,m); print(f'  gain [{m}] {ci[1]:+.3f} IC95 [{ci[0]:+.3f};{ci[2]:+.3f}] P>0={pp:.2f}')
    if filtre is None: rb.to_csv('/home/claude/data/pred_indices_18ports.csv',index=False)
P.to_csv('/home/claude/data/panel_modele.csv',index=False)
