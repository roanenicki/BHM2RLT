import numpy as np, pandas as pd
from scipy.stats import binomtest
u=pd.read_csv('/home/claude/data/ucdp_monde.csv',low_memory=False,parse_dates=['date_start'])
u=u.drop_duplicates(['date_start','latitude','longitude','best','side_a','side_b'])
R=pd.read_csv('/home/claude/data/generalisation_alerte.csv')
base=[]
for _,r in R.iterrows():
    s=u[u.country==r.pays].groupby(pd.Grouper(key='date_start',freq='W-SAT')).best.sum()
    s=s.reindex(pd.date_range('2018-06-30','2026-08-29',freq='W-SAT'),fill_value=0)
    mu=s.shift(1).rolling(26,min_periods=13).mean(); sd=s.shift(1).rolling(26,min_periods=13).std()
    al=((s>mu+2*sd)&(s>0)).astype(int)
    win=al.rolling(13,min_periods=13).max()['2019-06-01':'2026-08-29']   # fenêtre 12 semaines + semaine de fermeture
    base.append(win.mean())
R['base']=base
n=len(R); k=R.premiere_alerte.notna().sum(); p0=np.mean(base)
print(R[['id','pays','avance_semaines','base','escalade']].round(2).to_string(index=False))
print('alertes',k,'/',n,' taux de base moyen',round(p0,3),' binom p (unilat.)',round(binomtest(k,n,p0,alternative='greater').pvalue,3),
      ' p si base 0.5', round(binomtest(k,n,0.5,alternative='greater').pvalue,3))
print('avance médiane',R.avance_semaines.median(),' escalade médiane',R.escalade.median())
